package com.example.serivenovigradd;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class Login extends AppCompatActivity {

    private List<People>group = new ArrayList();
    DataBaseHelper databasehelper;
    EditText username,password;
    Button login;
    Button register;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        databasehelper = new DataBaseHelper(this);
        username =  (EditText) findViewById(R.id.uusername);
        password =  (EditText) findViewById(R.id.upassword);
        login =     (Button)   findViewById(R.id.ulogin);
        register =  (Button)   findViewById(R.id.uregister);

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Login.this,Register.class));
            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean tua = false;
                //admmin passwords and username
                if(username.getText().toString().equals("IAMADMIN") && password.getText().toString().equals("IAMSPONGEBOB")) {
                    startActivity(new Intent(Login.this, AdminScreen.class));
                    tua = true;
                }else{
                    getDatabase();
                    for(int a =0; a<group.size() ;a++){
                        String u = group.get(a).getUsername();
                        String p = group.get(a).getPassword();
                        //if matched
                        if(username.getText().toString().equals(u) && password.getText().toString().equals(p)){
                            Toast.makeText(Login.this, "login successful", Toast.LENGTH_SHORT).show();
                            tua = true;
                            databasehelper.itishim(group.get(a));

                            if(group.get(a).getJobtype().equals("1"))
                                startActivity(new Intent(Login.this, EmployeeLoggedIn.class));
                            else
                                startActivity(new Intent(Login.this, UserLoggedIn.class));
                        }
                    }
                }
                if(tua ==false)
                    Toast.makeText(Login.this, "sorry, no match found", Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void getDatabase(){
        group = databasehelper.getThemAll();
    }
}