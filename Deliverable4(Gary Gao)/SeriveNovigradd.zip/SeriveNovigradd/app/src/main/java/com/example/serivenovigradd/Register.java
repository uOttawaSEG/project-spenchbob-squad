package com.example.serivenovigradd;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Register extends AppCompatActivity {

    private EditText lastname,firstname,username,birthday,address,password;
    private Button registerE,registerU,cancel;
    private DataBaseHelper databasehelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        databasehelper = new DataBaseHelper(this);
        lastname = (EditText)findViewById(R.id.xlastname);
        firstname = (EditText)findViewById(R.id.xfirstname);
        username = (EditText)findViewById(R.id.xemail);//***
        birthday = (EditText)findViewById(R.id.xbirthday);
        address = (EditText)findViewById(R.id.xaddress);
        password = (EditText)findViewById(R.id.xpassword);
        registerE = (Button)findViewById(R.id.xre);
        registerU = (Button)findViewById(R.id.xru);
        cancel = (Button)findViewById(R.id.cancel);


        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Register.this,Login.class));
            }
        });


        //registering employee/ local branch
        registerE.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //creating an employee object

                People temp;
                boolean checkit = validate(username.getText().toString(), lastname.getText().toString(),
                        firstname.getText().toString(),birthday.getText().toString(),address.getText().toString(),
                        password.getText().toString());
                if(checkit ==true) {
                    try{
                        //Branch/Employee information
                        temp = new People(username.getText().toString(), password.getText().toString(),
                                birthday.getText().toString(), address.getText().toString(), firstname.getText().toString(),
                                lastname.getText().toString(), "1");

                        Toast.makeText(Register.this, temp.toString(), Toast.LENGTH_SHORT).show();
                    }catch(Exception x){
                        Toast.makeText(Register.this, "failed to create employee", Toast.LENGTH_SHORT).show();
                        temp = new People("error", "error", "error", "error",
                                "error", "error", "0");
                    }


                    boolean result = databasehelper.addPeople(temp);
                    if(result ==true){
                        Toast.makeText(Register.this, "successfully registered", Toast.LENGTH_SHORT).show();
                        lastname.setText("");
                        firstname.setText("");
                        username.setText("");//***
                        birthday.setText("");
                        address.setText("");
                        password.setText("");
                    }
                    else
                        Toast.makeText(Register.this, "registered failed", Toast.LENGTH_SHORT).show();
                }
            }
        });

        //registering user
        registerU.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //creating an user object

                People temp;
                boolean checkit = validate(username.getText().toString(), lastname.getText().toString(),
                        firstname.getText().toString(),birthday.getText().toString(),address.getText().toString(),
                        password.getText().toString());
                if(checkit ==true) {
                    try {
                        temp = new People(username.getText().toString(), password.getText().toString(),
                                birthday.getText().toString(), address.getText().toString(), firstname.getText().toString(),
                                lastname.getText().toString(), "2");
                        Toast.makeText(Register.this, temp.toString(), Toast.LENGTH_SHORT).show();
                    }catch(Exception x){
                        Toast.makeText(Register.this, "failed to create user", Toast.LENGTH_SHORT).show();
                        temp = new People("error", "error", "error", "error",
                                "error", "error", "0");
                    }

                    boolean result = databasehelper.addPeople(temp);
                    if(result ==true)
                        Toast.makeText(Register.this, "successfully registered", Toast.LENGTH_SHORT).show();
                    else
                        Toast.makeText(Register.this, "registered failed", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    public boolean validate(String eusername,String elastname,String efirstname,String ebirthday,String eaddress,String epassword){
        if(TextUtils.isEmpty(eusername)){
            username.setError("Username is required");
            return false;
        }
        if(TextUtils.isEmpty(epassword)||epassword.length()<6){
            password.setError("Password is required and has a length >=6");
            return false;
        }
        if(TextUtils.isEmpty(elastname)){
            lastname.setError("lastname is required");
            return false;
        }
        if(TextUtils.isEmpty(efirstname)){
            firstname.setError("firstname is required");
            return false;
        }
        if(TextUtils.isEmpty(ebirthday)||ebirthday.length()<8){
            birthday.setError("birthday is requiredand has a length >=8");
            return false;
        }
        if(TextUtils.isEmpty(eaddress)||ebirthday.length()<5){
            address.setError("Email is required and has a length >5");
            return false;
        }
        return true;
    }
}