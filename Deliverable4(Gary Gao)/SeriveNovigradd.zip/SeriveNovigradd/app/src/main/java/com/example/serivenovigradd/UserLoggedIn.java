package com.example.serivenovigradd;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;

public class UserLoggedIn extends AppCompatActivity {
    private TextView welcome;
    private DataBaseHelper databasehelper;
    private People myself;
    private EditText text;
    private Button address;
    private Button hours;
    private Button service;
    private ListView list;
    private List<People> BranchList;
    private List<People> mylist;

    ArrayAdapter cus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_logged_in);
        databasehelper = new DataBaseHelper(this);

        //set up parts on the screen
        welcome = (TextView)findViewById(R.id.tinytext);
        text = (EditText)findViewById(R.id.IDD_text);
        address = (Button)findViewById(R.id.IDD_address);
        hours = (Button)findViewById(R.id.IDD_workhours);
        service = (Button)findViewById(R.id.IDD_services);
        list = (ListView)findViewById(R.id.IDD_list);

        //get the one who logged in
        myself = databasehelper.getTheChosenOne();

        //get all services
        BranchList = databasehelper.getBranches();

        //get all lists updated
        updateIt();

        String myname = myself.getFirstname()+" "+myself.getLastname();

        if(DataBaseHelper.approvedList.get(myname)!=null)
            welcome.setText("WELCOME "+myself.getFirstname()+" "+myself.getLastname()
                    +" Your current branch is: "+DataBaseHelper.approvedList.get(myname));
        else if(DataBaseHelper.requestList.get(myname)!=null)
            welcome.setText("WELCOME "+myself.getFirstname()+" "+myself.getLastname()
                    +" Your current branch is: WAITING FOR APPROVAL");
        else{
            welcome.setText("WELCOME "+myself.getFirstname()+" "+myself.getLastname()
                    +" Your current branch is: NOT REQUESTED FOR SERVICE");
        }
        //if the user has searched an address
        address.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //get the text and verify them
                String address = text.getText().toString();
                boolean temp = verify(address,1);

                mylist = new ArrayList<People>();

                //if correct input are entered
                if(temp){

                    setIt(mylist);


                    for(int a =0;a<BranchList.size();a++){
                        if(BranchList.get(a).getAddress().equals(address)){
                            mylist.add(BranchList.get(a));
                        }
                    }
                    setIt(mylist);
                }
                else{//if wrong input are entered
                    setIt(mylist);
                    Toast.makeText(UserLoggedIn.this, "wrong input detected,please try again", Toast.LENGTH_SHORT).show();
                }

            }
        });

        hours.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String hours = text.getText().toString();
                boolean temp = verify(hours,2);

                mylist = new ArrayList<People>();

                //if correct input are entered
                if(temp){

                    setIt(mylist);


                    for(int a =0;a<BranchList.size();a++){
                        if(BranchList.get(a).getLastname().equals(hours)){
                            mylist.add(BranchList.get(a));
                        }
                    }
                    setIt(mylist);
                }
                else{//if wrong format are entered
                    setIt(mylist);
                    Toast.makeText(UserLoggedIn.this, "wrong input detected,please try again", Toast.LENGTH_SHORT).show();
                }
            }
        });
        service.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String serv = text.getText().toString();
                boolean temp = verify(serv,3);

                mylist = new ArrayList<People>();

                //if correct input are entered
                if(temp){

                    setIt(mylist);

                    List<People> listlist = databasehelper.getBranchServices();

                    for(int a =0;a<listlist.size();a++){
                        People current = listlist.get(a);
                        ArrayList<String> servicez = People.seperatetify(current.getPassword());
                        for(int b =0;b<servicez.size();b++){
                            if(serv.equals(servicez.get(b))){
                                String tempname = current.getUsername();
                                mylist.add(databasehelper.getThisGuy(tempname.substring(0,tempname.length()-7)));
                            }
                        }

                    }

                    setIt(mylist);
                }
                else{//if wrong format are entered
                    setIt(mylist);
                    Toast.makeText(UserLoggedIn.this, "wrong input detected,please try again", Toast.LENGTH_SHORT).show();
                }
            }
        });

        list.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> parent,View view, int position, long id){
                //Figure out which one to delete, then delete
                People clickedPeople = (People) parent.getItemAtPosition(position);
                String clickedUsername = clickedPeople.getUsername();

                String myname = myself.getFirstname()+" "+myself.getLastname();

                updateIt();

                //if already requested
                if(DataBaseHelper.requestList.get(myname)!=null)
                    Toast.makeText(UserLoggedIn.this, "You already requested for a branch!", Toast.LENGTH_SHORT).show();
                //if already approved
                else if (DataBaseHelper.approvedList.get(myname)!=null)
                    Toast.makeText(UserLoggedIn.this, "You already have a branch!", Toast.LENGTH_SHORT).show();
                //if not yet requested
                else{
                    databasehelper.addRequest(myname,clickedUsername,66);
                    Toast.makeText(UserLoggedIn.this, "You have successfully requested  for a branch service", Toast.LENGTH_SHORT).show();
                    updateIt();
                }
            }
        });
    }
    private  boolean verify (String message,int type){
        if(message.equals("")||message.equals(null))
            return false;
        return true;
    }
    private  void setIt (List a ){
        cus = new ArrayAdapter<People>(this,android.R.layout.simple_list_item_1,a);
        list.setAdapter(cus);
    }

    private void updateIt(){
        databasehelper.updateLists(66);
        databasehelper.updateLists(77);
        databasehelper.updateLists(88);
    }
}