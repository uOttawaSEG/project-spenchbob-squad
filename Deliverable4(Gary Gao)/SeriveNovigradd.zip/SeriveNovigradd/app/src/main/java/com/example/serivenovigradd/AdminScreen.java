package com.example.serivenovigradd;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;


public class AdminScreen extends AppCompatActivity {

    private List<People> group = new ArrayList();
    private ArrayAdapter cus;
    private DataBaseHelper databasehelper;
    private Button delete;
    private Button search;
    private EditText blank;
    private ListView list;
    private Button services;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_screen);
        databasehelper = new DataBaseHelper(this);

        delete = (Button)findViewById(R.id.ID_TUA);
        search = (Button)findViewById(R.id.ID_findd);
        blank = (EditText)findViewById(R.id.ID_Blank);
        list = (ListView)findViewById(R.id.ID_listview);
        services = (Button)findViewById(R.id.ID_Services2);
        setIt(databasehelper);

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean found =false;
                group = databasehelper.getThemAll();
                for(int a =0; a<group.size();a++){
                    if(group.get(a).getUsername().equals(blank.getText().toString())){

                        Toast.makeText(AdminScreen.this, "User Found ", Toast.LENGTH_SHORT).show();
                        found = true;

                    }
                }
                boolean answer = databasehelper.deleteOne("'"+ blank.getText().toString()+"'");
                if(found ==true) {
                    Toast.makeText(AdminScreen.this, "user/employee deleted", Toast.LENGTH_SHORT).show();
                    try {
                        databasehelper.deleteOne("'" + blank.getText().toString() + "7758521'");
                        Toast.makeText(AdminScreen.this, "employee service list deleted", Toast.LENGTH_SHORT).show();
                    }catch(Exception e){

                    }

                }
                else{
                    Toast.makeText(AdminScreen.this, "failed ", Toast.LENGTH_SHORT).show();
                }
                DataBaseHelper databasehelper = new DataBaseHelper(AdminScreen.this);
                setIt(databasehelper);
            }
        });

        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text = blank.getText().toString();
                boolean found = false;
                group = databasehelper.getThemAll();
                if(text!=null&&text!=""){
                    for(int a =0; a<group.size();a++){
                        if(group.get(a).getUsername().equals(text)){

                            Toast.makeText(AdminScreen.this, "User Found ", Toast.LENGTH_SHORT).show();
                            found = true;

                        }
                    }
                    if(found ==false)
                        Toast.makeText(AdminScreen.this, "User not Found ", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(AdminScreen.this, "Please enter something to search", Toast.LENGTH_SHORT).show();
                }


            }
        });
        services.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(AdminScreen.this, AdminActivity2.class));
            }
        });
    }
    public void setIt(DataBaseHelper helper){
        cus = new ArrayAdapter<People>(this,android.R.layout.simple_list_item_1,helper.getThemAll());
        list.setAdapter(cus);
    }
}