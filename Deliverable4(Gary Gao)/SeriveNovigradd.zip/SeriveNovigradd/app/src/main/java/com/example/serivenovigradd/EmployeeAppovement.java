package com.example.serivenovigradd;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.sql.DatabaseMetaData;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

public class EmployeeAppovement extends AppCompatActivity {

    private EditText text;
    private Button find;
    private Button approve;
    private Button reject;
    private ListView list;
    private ArrayAdapter cus;
    DataBaseHelper databasehelper;
    private List<String> requestlisted;

    private boolean isItFound = false;
    private String isItFoundString ="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employee_appovement);

        text = findViewById(R.id.IDDD_text);
        find = findViewById(R.id.IDDD_find);
        approve = findViewById(R.id.IDDD_approve);
        reject = findViewById(R.id.IDDD_reject);
        list = findViewById(R.id.IDDD_list);

        databasehelper = new DataBaseHelper(this);
        getList();

        find.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //verify things entered***********

                String tempname = text.getText().toString();
                if (tempname.equals("")) {
                    Toast.makeText(EmployeeAppovement.this, "Nothing is entered,check again", Toast.LENGTH_SHORT).show();
                } else {
                    boolean found = false;
                    update();
                    for (int a = 0; a < requestlisted.size(); a++) {
                        if (requestlisted.get(a).equals(tempname)) {
                            found = true;
                            Toast.makeText(EmployeeAppovement.this, "User found", Toast.LENGTH_SHORT).show();
                            isItFound = true;
                            isItFoundString = tempname;
                            break;
                        }
                    }

                    if (found == false)
                        Toast.makeText(EmployeeAppovement.this, "User not found", Toast.LENGTH_SHORT).show();

                }
            }
        });

        approve.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //verify things entered***********
                String tempname = text.getText().toString();
                if (tempname.equals("")) {
                    Toast.makeText(EmployeeAppovement.this, "Nothing is entered,check again", Toast.LENGTH_SHORT).show();
                } else {
                    if (tempname.equals(isItFoundString) && isItFound == true) {
                        try {
                            boolean ok = databasehelper.deleteFromLists("\'" + tempname + "\'");
                            databasehelper.addRequest(tempname, DataBaseHelper.getTheChosenOne().getUsername(), 77);
                            getList();
                            Toast.makeText(EmployeeAppovement.this, "approved", Toast.LENGTH_SHORT).show();
                            text.setText("");
                            isItFound = false;
                            isItFoundString = "";
                        } catch (Exception e) {
                            System.out.println(e);
                        }
                    } else {
                        Toast.makeText(EmployeeAppovement.this, "You have to find it first with the find button", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        reject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //verify things entered***********
                String tempname = text.getText().toString();
                if(tempname.equals(isItFoundString)&&isItFound==true) {
                    boolean i = databasehelper.deleteFromLists("\'"+tempname+"\'");
                    databasehelper.addRequest(tempname,DataBaseHelper.getTheChosenOne().getUsername(),88);
                    getList();
                    Toast.makeText(EmployeeAppovement.this, "rejected", Toast.LENGTH_SHORT).show();
                    text.setText("");
                    isItFound=false;
                    isItFoundString = "";
                }
                else{
                    Toast.makeText(EmployeeAppovement.this, "You have to find it first with the find button", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void getList (){
        update();
        Hashtable<String,String> temp = DataBaseHelper.requestList;
        requestlisted =   new ArrayList<String>();
        for (Map.Entry<String, String> e : temp.entrySet()){
            if(e.getValue().equals(DataBaseHelper.getTheChosenOne().getUsername())) {
                String tempeople = e.getKey();
                requestlisted.add(tempeople);
            }
        }

        cus = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,requestlisted);
        list.setAdapter(cus);
    }

    private void update(){
        databasehelper.updateLists(66);
        databasehelper.updateLists(77);
        databasehelper.updateLists(88);
    }
}
