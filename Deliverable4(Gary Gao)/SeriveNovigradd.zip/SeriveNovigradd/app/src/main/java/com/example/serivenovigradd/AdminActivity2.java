package com.example.serivenovigradd;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

public class AdminActivity2 extends AppCompatActivity {
    private DataBaseHelper databsehelper;
    private ArrayAdapter cus;
    private Button add;
    private Button replace;
    private Button deletee;
    private EditText services;
    private EditText forms;
    private EditText documents;
    private ListView list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin2);

        databsehelper = new DataBaseHelper(this);

        add = findViewById(R.id.ID_Add);
        replace = findViewById(R.id.ID_Replace);
        deletee = findViewById(R.id.ID_Deletee);
        services = findViewById(R.id.ID_Services);
        forms = findViewById(R.id.ID_Forms);
        documents =  findViewById(R.id.ID_Documents);
        list = findViewById(R.id.ID_List);

        getList();

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //get inpputs
                String service = services.getText().toString();
                String form = forms.getText().toString();
                String document = documents.getText().toString();

                //add services
                databsehelper.addServices(service, form , document);
                //refresh list
                getList();

                //reset to blank
                services.setText("");
                forms.setText("");
                documents.setText("");
            }
        });

        replace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //get inputs
                String service = services.getText().toString();
                String form = forms.getText().toString();
                String document = documents.getText().toString();
                try {
                    databsehelper.deleteOne("'"+ service+"'");
                    Toast.makeText(AdminActivity2.this, "replaement success", Toast.LENGTH_SHORT).show();
                }
                catch(Exception e){
                    Toast.makeText(AdminActivity2.this, "failed to find the service", Toast.LENGTH_SHORT).show();
                }

                //refresh
                databsehelper.addServices(service,form,document);
                getList();
            }
        });

        deletee.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //get inputs
                String service = services.getText().toString();
                String form = forms.getText().toString();
                String document = documents.getText().toString();
                try {
                    databsehelper.deleteOne("'"+ service+"'");
                    Toast.makeText(AdminActivity2.this, "delte successful", Toast.LENGTH_SHORT).show();
                }
                catch(Exception e){
                    Toast.makeText(AdminActivity2.this, "failed to delete the service", Toast.LENGTH_SHORT).show();
                }

                getList();
            }
        });
    }

    private void getList(){
        cus = new ArrayAdapter<People>(this,android.R.layout.simple_list_item_1,databsehelper.getServices());
        list.setAdapter(cus);
    }
}