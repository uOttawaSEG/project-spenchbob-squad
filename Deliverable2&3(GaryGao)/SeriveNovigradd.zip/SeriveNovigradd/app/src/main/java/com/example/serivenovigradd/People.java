package com.example.serivenovigradd;

import java.util.ArrayList;

public class People {
    private String username;
    private String password;
    private String birthday;
    private String address;
    private String firstname;
    private String lastname;//working hours for branches
    private String jobtype;// 1 for employee, 2 for user, 99 for services


    public People(){

    }
    public People(String u, String p){
        username = u;
        password = p;
    }

    public People(String username, String password, String birthday, String address, String firstname, String lastname, String jobtype) {
        this.username = username;
        this.password = password;
        this.birthday = birthday;
        this.address = address;
        this.firstname = firstname;
        this.lastname = lastname;
        this.jobtype = jobtype;
    }


    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getJobtype() {
        return jobtype;
    }

    public void setJobtype(String jobtype) {
        this.jobtype = jobtype;
    }


    @Override
    public String toString() {
        String job="";
        if(Integer.parseInt(jobtype)==1){
            job = "Employee";
        }
        else if (Integer.parseInt(jobtype)==2){
            job = "User";
        }
        if(Integer.parseInt(jobtype)==2||Integer.parseInt(jobtype)==1) {
            return "people{" +
                    "username: '" + username + '\'' +
                    ", password: '" + password + '\'' +
                    ", birthday: '" + birthday + '\'' +
                    ", address: '" + address + '\'' +
                    ", firstname: '" + firstname + '\'' +
                    ", lastname: '" + lastname + '\'' +
                    ", jobtype: " + job +
                    '}';
        }
        if(Integer.parseInt(jobtype)==99){
            ArrayList forms = seperatetify(password);
            ArrayList documents = seperatetify(birthday);
            String tempform="";
            for(int a =0;a<forms.size();a++){
                tempform = tempform+forms.get(a)+"\n";
            }
            String tempdoc="";
            for(int a =0;a<documents.size();a++){
                tempdoc = tempdoc+documents.get(a)+"\n";
            }
            return "Service :"+ username+"\n"+
                    "Forms :"+"\n"+
                    tempform+
                    "Documents"+"\n"+
                    tempdoc;
        }
        if(Integer.parseInt(jobtype)==7758521){
            ArrayList forms = seperatetify(password);
            String tempform="";
            for(int a =0;a<forms.size();a++){
                tempform = tempform+forms.get(a)+"\n";
            }
            return "Username :"+ new String(username.substring(0,username.length()-7))+"\n"+
                    "Services :"+"\n"+tempform;

        }
        else{
            return "";
        }
    }
    public static ArrayList seperatetify(String temp ){
        ArrayList group = new ArrayList();
        while(temp.indexOf(",")!=-1) {
            int tempint = temp.indexOf(",");
            group.add(temp.substring(0,tempint));
            temp = temp.substring(tempint+1,temp.length());
            //System.out.println(temp);
        }
        group.add(temp);

        return group;
    }
}
