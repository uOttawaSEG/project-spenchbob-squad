package com.example.serivenovigradd;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class DataBaseHelper extends SQLiteOpenHelper {
    private static final int DATABASE_VERSION = 2;

    private static People THECHOSENONE;

    public static final String TABLE_PRODUCTS = "TABLE_PRODUCTS2";
    public static final String COLUMN_ID = "COLUMN_ID";
    public static final String COLUMN_USERNAME = "COLUMN_USERNAME";
    public static final String COLUMN_PASSWORD = "COLUMN_PASSWORD";
    public static final String COLUMN_BIRTHDAY = "COLUMN_BIRTHDAY";
    public static final String COLUMN_ADDRESS = "COLUMN_ADDRESS";
    public static final String COLUMN_FIRSTNAME = "COLUMN_FIRSTNAME";
    public static final String COLUMN_LASTNAME = "COLUMN_LASTNAME";
    public static final String COLUMN_JOBTYPE = "COLUMN_JOBTYPE";
    public DataBaseHelper(@Nullable Context context) {
        super(context, "SpenchBoB.db",null,DATABASE_VERSION);
        /*
        SQLiteDatabase db = this.getWritableDatabase();
        boolean result =true ;
        String query = "DELETE FROM "+ TABLE_PRODUCTS;
        Cursor cursor = db.rawQuery(query,null);

        if(cursor.moveToFirst()){
            result = true;
        }
        cursor.close();
        db.close();
        */
        List<People> temp = getServices();
        boolean bool1=false,bool2=false,bool3 = false;
        for(int x=0;x<temp.size();x++){
            if(temp.get(x).getUsername().equals("Drivers License")){
                bool1=true;
            }
            if(temp.get(x).getUsername().equals("Health Card")){
                bool2=true;
            }
            if(temp.get(x).getUsername().equals("Photo ID")){
                bool3=true;
            }
        }
        if(bool1==false)
            addServices("Drivers License","firstname,lastname,date of birth, address, license type","Proof of resident");
        if(bool2==false)
            addServices("Health Card", "firstname,lastname,date of birth, address","Proof of resident,Proof of status");
        if(bool3==false)
        addServices("Photo ID","firstname,lastname,date of birth,address","Proof of resident,photo of customer");


    }

    @Override
    //called the first time the database is accessed. There should be code in here to create database
    public void onCreate(SQLiteDatabase db){
        String createTableStatements ="CREATE TABLE "+ TABLE_PRODUCTS +" ("
                +COLUMN_USERNAME + " TEXT, "+COLUMN_PASSWORD+" TEXT,"+COLUMN_BIRTHDAY+" TEXT,"
                +COLUMN_ADDRESS + " TEXT, "+COLUMN_FIRSTNAME+ " TEXT, "+COLUMN_LASTNAME+" TEXT,"
                +COLUMN_JOBTYPE+ " INTEGER)";
        db.execSQL(createTableStatements);
    }


    @Override
    //called when the version number changed, prevents breaking
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        db.execSQL("DROP TABLE IF EXISTS " + "SpenchBoB.db");
        onCreate(db);
    }

    public boolean addPeople(People people){

        //get the data repository in write mode
        SQLiteDatabase db = this.getReadableDatabase();

        //create a map of value, where column names are the keys
        ContentValues c = new ContentValues();
        /*contentvalues store data in pairs
         *cv.put("name",value);
         *cv.getString("name");
         * */

        c.put(COLUMN_USERNAME,people.getUsername());
        c.put(COLUMN_PASSWORD,people.getPassword());
        c.put(COLUMN_BIRTHDAY,people.getBirthday());
        c.put(COLUMN_ADDRESS,people.getAddress());
        c.put(COLUMN_FIRSTNAME,people.getFirstname());
        c.put(COLUMN_LASTNAME,people.getLastname());
        c.put(COLUMN_JOBTYPE,people.getJobtype());

        long insertion = db.insert(TABLE_PRODUCTS,null,c);
        db.close();
        if(insertion==-1){
            return false;
        }
        else{
            return true;
        }

    }

    public List<People> getThemAll(){ //retrieve users and employees
        List<People> newlist = new ArrayList();

        String temp = "SELECT * FROM " + TABLE_PRODUCTS;

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(temp,null);

        if(cursor.moveToFirst()){

            do{
                String username = cursor.getString(1);
                String password = cursor.getString(2);
                String birthday = cursor.getString(3);
                String address = cursor.getString(4);
                String firstnamee = cursor.getString(5);
                String lastnamee = cursor.getString(6);
                String jobtypee = cursor.getString(7);

                People people = new People(username,password,birthday,address,firstnamee,lastnamee,jobtypee);
                if(Integer.parseInt(jobtypee)==1||Integer.parseInt(jobtypee)==2||Integer.parseInt(jobtypee)==7758521)
                    newlist.add(people);

            }while(cursor.moveToNext());
        }
        else{

        }
        db.close();
        cursor.close();
        return newlist;
    }

    //get all the services from the admin
    public List<People> getServices(){
        List<People> newlist = new ArrayList();

        String temp = "SELECT * FROM " + TABLE_PRODUCTS;

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(temp,null);

        if(cursor.moveToFirst()){

            do{
                String username = cursor.getString(1);
                String password = cursor.getString(2);
                String birthday = cursor.getString(3);
                String address = cursor.getString(4);
                String firstnamee = cursor.getString(5);
                String lastnamee = cursor.getString(6);
                String jobtypee = cursor.getString(7);

                People people = new People(username,password,birthday,address,firstnamee,lastnamee,jobtypee);
                if(Integer.parseInt(jobtypee)==99)
                    newlist.add(people);

            }while(cursor.moveToNext());
        }
        else{

        }
        db.close();
        cursor.close();
        return newlist;
    }
    public boolean addServices(String Service,String forms, String documents){

        //get the data repository in write mode
        SQLiteDatabase db = this.getReadableDatabase();

        //create a map of value, where column names are the keys
        ContentValues c = new ContentValues();
        /*contentvalues store data in pairs
         *cv.put("name",value);
         *cv.getString("name");
         * */

        c.put(COLUMN_USERNAME,Service);
        c.put(COLUMN_PASSWORD,forms);
        c.put(COLUMN_BIRTHDAY,documents);
        c.put(COLUMN_ADDRESS,"Secret");
        c.put(COLUMN_FIRSTNAME,"Secret");
        c.put(COLUMN_LASTNAME,"Secret");
        c.put(COLUMN_JOBTYPE,99);

        long insertion = db.insert(TABLE_PRODUCTS,null,c);
        db.close();
        if(insertion==-1){
            return false;
        }
        else{
            return true;
        }

    }

    //set the one who has logged in
    public static void itishim(People theman){
        THECHOSENONE = theman;
    }

    //return the one who has logged out
    public static People getTheChosenOne(){
        return THECHOSENONE;
    }

    public boolean deleteOne(String temp ){
        SQLiteDatabase db = this.getWritableDatabase();
        boolean result =true ;
        String query = "DELETE FROM "+ TABLE_PRODUCTS+" WHERE "+ COLUMN_USERNAME + " = " +temp ;
        Cursor cursor = db.rawQuery(query,null);

        if(cursor.moveToFirst()){
            result = true;
        }
        cursor.close();
        db.close();
        return result;
    }
    //checking if this branch service list exist
    public String checkIfExist(String name){

        String temp = "SELECT * FROM " + TABLE_PRODUCTS;

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(temp,null);

        if(cursor.moveToFirst()){

            do{
                String username = cursor.getString(1);
                String password = cursor.getString(2);
                String jobtypee = cursor.getString(7);

                if(Integer.parseInt(jobtypee)==7758521 && username.equals(name))
                    return password;
            }while(cursor.moveToNext());
        }
        else{

        }
        db.close();
        cursor.close();
        return "-1";
    }

    public ArrayList<People> findMeTheseServices(String list){
        //The arraylist we are going to return
        ArrayList temp = new ArrayList<People>();

        //the arratlist we got from the employee
        ArrayList temp2 = People.seperatetify(list);

        List<People> temp3 = getServices();
        for(int a=0;a<temp3.size();a++){
            for(int b=0;b<temp2.size();b++){
                if(temp3.get(a).getUsername().equals(temp2.get(b))){
                    temp.add(temp3.get(a));
                }
            }
        }
        return temp;
    }
}
