package com.example.serivenovigradd;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class EmployeeLoggedIn extends AppCompatActivity {

    DataBaseHelper databasehelper;
    private TextView text;
    private Button setHours;
    private EditText hours;
    private Button addServices;
    private ListView thelist;
    private Button requests;
    private List<People> list;
    private ArrayAdapter cus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employee_logged_in);

        text = findViewById(R.id.ID_Text);
        setHours = findViewById(R.id.ID_Set);
        hours = findViewById(R.id.ID_Work);
        addServices = findViewById(R.id.ID_System);
        thelist = findViewById(R.id.ID_listlist);
        requests = findViewById(R.id.ID_requests);
        databasehelper = new DataBaseHelper(this);

        //set up the text
        People me  = DataBaseHelper.getTheChosenOne();
        text.setText("Welcome "+me.getUsername()+"!, Your working hours is "+me.getLastname()+
                "\n to delete a service, simply click on the \n" +
                "service, to add, click the add service button!");

        //getTheList
        String temp = databasehelper.checkIfExist(me.getUsername()+"7758521");
        //if there is no pre defined services
        Toast.makeText(EmployeeLoggedIn.this, "the result after calling is "+temp, Toast.LENGTH_SHORT).show();
        if(temp.equals("-1")){
            list = databasehelper.getServices();
            String services="";
            for(int u = 0; u<list.size(); u++){
                services = services+list.get(u).getUsername()+",";
            }
            databasehelper.addPeople(new People(me.getUsername()+"7758521",services,
                    "Secret","Secret","Secret","Secret","7758521"));
            Toast.makeText(EmployeeLoggedIn.this, services, Toast.LENGTH_SHORT).show();
            getList(list);
        }
        //if there is defined services, temp is already the services
        else{
            list = databasehelper.findMeTheseServices(temp);
            getList(list);
        }

        setHours.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(TextUtils.isEmpty(hours.getText().toString())){
                    Toast.makeText(EmployeeLoggedIn.this, "nothing is entered", Toast.LENGTH_SHORT).show();
                }
                else if(hours.getText().toString().indexOf("~")==-1){
                    Toast.makeText(EmployeeLoggedIn.this, "~ is not entered", Toast.LENGTH_SHORT).show();
                }
                else {
                    People arranged = new People(me.getUsername(), me.getPassword(),
                            me.getBirthday(), me.getAddress(), me.getFirstname(),
                            hours.getText().toString(), "1");
                    databasehelper.deleteOne("'"+me.getUsername()+"'");
                    databasehelper.addPeople(arranged);
                    text.setText("Welcome "+me.getUsername()+"!, Your working hours is "+arranged.getLastname()+
                            "\n to delete a service, simply click on the \n" +
                            "service, to add, click the add service button!");
                    Toast.makeText(EmployeeLoggedIn.this, "working hours is setted", Toast.LENGTH_SHORT).show();
                }
            }
        });

        //another acitivity, add services from the admin
        addServices.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(EmployeeLoggedIn.this, EmployeeAddServices.class));

            }
        });

        //approve or reject service requests
        requests.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        thelist.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> parent,View view, int position, long id){
                //Figure out which one to delete, then delete
                People clickedPeople = (People) parent.getItemAtPosition(position);
                String clickedUsername = clickedPeople.getUsername();
                databasehelper.deleteOne("'"+me.getUsername()+"7758521'");

                //Correct the service object
                String newString ="";
                for(int x =0;x<list.size();x++){
                    if(!list.get(x).getUsername().equals(clickedUsername)){
                        newString+=list.get(x).getUsername()+",";
                    }
                }
                databasehelper.addPeople(new People(me.getUsername()+"7758521",newString,
                        "Secret","Secret","Secret","Secret","7758521"));


                ArrayList<People> t = databasehelper.findMeTheseServices(newString);
                list =t;
                getList(t);
                Toast.makeText(EmployeeLoggedIn.this, "This service is deleted " +
                        "in this branch", Toast.LENGTH_SHORT).show();
            }
        });

    }
    private void getList (List<People> alist ){
        cus = new ArrayAdapter<People>(this,android.R.layout.simple_list_item_1,alist);
        thelist.setAdapter(cus);
    }
}