package com.example.serivenovigradd;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class EmployeeAddServices extends AppCompatActivity {
    private DataBaseHelper databasehelper;
    private Button back;
    private ListView alist;
    private TextView title;
    private ArrayAdapter cuss;

    private People chosen;//the current branch
    private ArrayList<People> chosenlist; //services that the user already have


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employee_add_services);

        back = findViewById(R.id.ID_GOBACK);
        alist = findViewById(R.id.ID_ALIST);
        title = findViewById(R.id.ID_TITLE);

        databasehelper = new DataBaseHelper(this);

        title.setText("This list consists all the services that are not offeredin this branch," +
                " click on the service you want to offer, this page "+
                "only support to add a single service to the branch(come back for more)!");

        //find the services that the branch already have
        chosen = DataBaseHelper.getTheChosenOne();
        String ser = databasehelper.checkIfExist(chosen.getUsername()+"7758521");
        chosenlist = databasehelper.findMeTheseServices(ser);

        //colloect all the services from the admin
        List<People> allservices = databasehelper.getServices();


        for(int a =0;a<allservices.size();a++){
            for (int b =0;b<chosenlist.size();b++){
                if(allservices.get(a).getUsername().equals(chosenlist.get(b).getUsername())){
                    allservices.remove(a);
                }
            }
        }

        getList(allservices);


        alist.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id){
                People clickedPeople = (People) parent.getItemAtPosition(position);
                String clickedService = clickedPeople.getUsername();
                databasehelper.deleteOne("'"+chosen.getUsername()+"7758521'");

                allservices.remove(clickedPeople);
                getList(allservices);

                String record="";
                for(int a =0;a<chosenlist.size();a++){
                    record+=chosenlist.get(a).getUsername()+",";
                }
                if(record.indexOf(clickedService)==-1)
                    record+=clickedService;
                People newChosen =new People(chosen.getUsername()+"7758521",record,
                        "Secret","Secret","Secret","Secret","7758521");
                databasehelper.addPeople(newChosen);
                Toast.makeText(EmployeeAddServices.this, "This service is added " +
                        "to this branch", Toast.LENGTH_SHORT).show();
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(EmployeeAddServices.this, EmployeeLoggedIn.class));
            }
        });
    }
    private void getList (List<People> thelists ){
        cuss = new ArrayAdapter<People>(this,android.R.layout.simple_list_item_1,thelists);
        alist.setAdapter(cuss);
    }
}