package com.example.serivenovigradd;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

import org.w3c.dom.Text;

public class UserLoggedIn extends AppCompatActivity {
    private TextView welcome;
    private DataBaseHelper databasehelper;
    private People myself;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_logged_in);
        databasehelper = new DataBaseHelper(this);
        myself = databasehelper.getTheChosenOne();
        welcome = (TextView)findViewById(R.id.tinytext);
        welcome.setText("WELCOME "+myself.getFirstname()+" "+myself.getLastname()
        +" You have logged in as a user");
    }
}